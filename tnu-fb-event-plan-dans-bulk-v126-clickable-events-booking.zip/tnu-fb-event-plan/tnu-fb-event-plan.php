<?php
/**
 * Plugin Name: TNU FB Event list/plan (Tdans)
 * Description: Skapar en CPT för Events (/events), visar "Nästa event"-banner + eventslista via shortcodes, och skickar copy/paste-mail vid schemalagd tid (WP-Cron). Kan hämta event-data från Dans.se public API, inkl. mass-import via "TNU Event fetch".
 * Version: 1.2.3
 * Author: Tommy Nyman Utveckling (TNU)
 *
 * IMPORTANT:
 * - Inga //-rader får tas bort utan uttryckligt godkännande.
 * - Detta plugin är byggt för att fungera utan Facebook-API-OK: det skickar istället mail med copy/paste-underlag.
 */

if (!defined('ABSPATH')) { exit; }

// -----------------------------------------------------------------------------
// Constants
// -----------------------------------------------------------------------------
define('TNU_FBEVENT_VERSION', '1.1.2');
define('TNU_FBEVENT_PLUGIN_FILE', __FILE__);
define('TNU_FBEVENT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TNU_FBEVENT_PLUGIN_URL', plugin_dir_url(__FILE__));

class TNU_FB_Event_Plan {

	// -------------------------------------------------------------------------
	// Options keys
	// -------------------------------------------------------------------------
	const OPT = 'tnu_fbevent_options';

	// -------------------------------------------------------------------------
	// CPT & Meta keys
	// -------------------------------------------------------------------------
	const CPT = 'tnu_event';

	// Link back to Dans.se event id (for de-dupe)
	const META_DANS_EVENT_ID = '_tnu_dans_event_id';

	// City / Location structured options
	const META_CITY_OPTION       = '_tnu_event_city_option';    // norrkoping|nykoping|other
	const META_CITY_OTHER        = '_tnu_event_city_other';     // text when other
	const META_LOCATION_OPTION   = '_tnu_event_location_option';// borgen|sunlight_hotel|sunlight_gymspa|other
	const META_LOCATION_OTHER    = '_tnu_event_location_other'; // text when other

	// Date / Time
	const META_START_DATE      = '_tnu_event_start_date'; // YYYY-MM-DD
	const META_START_TIME      = '_tnu_event_start_time'; // HH:MM (24h)
	const META_END_TIME        = '_tnu_event_end_time';   // HH:MM (24h)

	const META_DEADLINE_AT     = '_tnu_event_deadline_at'; // YYYY-MM-DD HH:MM (optional)

	// Booking
	const META_BOOKING_URL     = '_tnu_event_booking_url';

	// Cover image: local attachment id (preferred) OR external url (fallback)
	const META_COVER_IMAGE_ID  = '_tnu_event_cover_image_id';
	const META_COVER_IMAGE_URL = '_tnu_event_cover_image_url';

	// Mail scheduling
	const META_MAIL_AT         = '_tnu_event_mail_at'; // YYYY-MM-DD HH:MM
	const META_MAIL_SENT_AT    = '_tnu_event_mail_sent_at'; // timestamp
	const META_MAIL_TO_OVERRIDE= '_tnu_event_mail_to_override'; // comma list (optional)
	const META_SUBJECT_OVERRIDE= '_tnu_event_subject_override'; // optional

	// -------------------------------------------------------------------------
	// Cron hook
	// -------------------------------------------------------------------------
	const CRON_HOOK = 'tnu_fbevent_cron_send_mails';

	// -------------------------------------------------------------------------
	// Menu slug
	// -------------------------------------------------------------------------
	const MENU_ROOT_SLUG     = 'tnu-root';
	const MENU_PLAN_SLUG     = 'tnu-fb-event-plan';
	const MENU_SETTINGS_SLUG = 'tnu-fb-event-settings';
	const MENU_FETCH_SLUG    = 'tnu-fb-event-fetch';

	// -------------------------------------------------------------------------
	// Dans.se API base
	// -------------------------------------------------------------------------
	const DANS_PUBLIC_EVENTS_ENDPOINT = 'https://dans.se/api/public/events/';

	// -------------------------------------------------------------------------
	// Default options
	// -------------------------------------------------------------------------
	public static function default_options() {
		return array(
			'events_slug'              => 'events',
			'default_mail_to'          => get_option('admin_email'),
			'default_subject_tpl'      => '{date} – {city} – {title}', // Default Date - City - Title
			'date_format_mode'         => 'human_long', // human_long | iso | slash | short_month | custom
			'date_format_custom'       => 'Y-m-d',
			'time_format_mode'         => 'start_end', // start_end | start_only | custom
			'time_format_custom'       => '{start_time}–{end_time}',
			'attach_cover'             => 1, // 1=attach cover image in mail
			'default_booking_url'      => 'https://tdans.se/event',
			'dans_reg_status'          => 'NONE_EXPIRED', // 0 | OPEN_FOR_REG | PUBLIC | NONE_EXPIRED | NOT_YET_SHOWN
			'fallback_image_url'       => 'https://media.tdans.se/2025/11/tdlogosmall-e1660139591215-2.avif',

			// Defaults for creating events
			'default_city_option'      => 'norrkoping',
			'default_city_other'       => '',
			'default_location_option'  => 'borgen',
			'default_location_other'   => '',
			'default_start_time'       => '18:00',
			'default_end_time'         => '19:00',

			// mail_field_order: drag/drop order
			'mail_field_order'         => array('cover_url','title','content','date','time','location'),

			
			'fetch_primary_group_ids'  => '3672', // Endast primaryEventGroup.id
			'fetch_group_ids'           => '', // Back-compat (används inte)
// Fetch settings: comma-separated ids to include in "TNU Event fetch"
			'fetch_group_ids'          => '3672,18336', // Example defaults; user can change
		);
	}

	// -------------------------------------------------------------------------
	// Boot
	// -------------------------------------------------------------------------
	public static function init() {
		

		// FRONTEND: tvinga bildhantering för event (archive + single)
		add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_event_image_css'));
		add_filter('post_thumbnail_html', array(__CLASS__, 'filter_post_thumbnail_html'), 20, 5);
		add_filter('the_content', array(__CLASS__, 'filter_event_content_images'), 9);
		add_filter('the_excerpt', array(__CLASS__, 'filter_event_excerpt_images'), 9);
add_action('init', array(__CLASS__, 'register_cpt'));
		add_action('init', array(__CLASS__, 'register_shortcodes'));

		add_action('admin_menu', array(__CLASS__, 'register_admin_menu'));
		add_action('admin_enqueue_scripts', array(__CLASS__, 'admin_assets'));

		// Place details "box" above the editor (brödtext)
		add_action('edit_form_after_title', array(__CLASS__, 'render_details_above_editor'));

		add_action('add_meta_boxes', array(__CLASS__, 'register_metaboxes'));
		add_action('save_post', array(__CLASS__, 'save_event_metaboxes'), 10, 2);

		add_filter('cron_schedules', array(__CLASS__, 'cron_schedules'));
		add_action(self::CRON_HOOK, array(__CLASS__, 'cron_run'));

		add_filter('post_type_link', array(__CLASS__, 'filter_event_permalink'), 10, 2);

		// Admin actions (buttons)
		add_action('admin_post_tnu_fbevent_send_test', array(__CLASS__, 'handle_send_test'));
		add_action('admin_post_tnu_fbevent_resend', array(__CLASS__, 'handle_resend'));
		add_action('admin_post_tnu_fbevent_copy_new', array(__CLASS__, 'handle_copy_new'));

		// Dans fetch: single
		add_action('wp_ajax_tnu_fbevent_fetch_dans_single', array(__CLASS__, 'ajax_fetch_dans_single'));

		// Dans fetch: bulk import
		add_action('admin_post_tnu_fbevent_bulk_import', array(__CLASS__, 'handle_bulk_import'));

		// Activation/deactivation
		register_activation_hook(TNU_FBEVENT_PLUGIN_FILE, array(__CLASS__, 'on_activate'));
		register_deactivation_hook(TNU_FBEVENT_PLUGIN_FILE, array(__CLASS__, 'on_deactivate'));
	}

	// -------------------------------------------------------------------------
	// Options helpers
	// -------------------------------------------------------------------------
	public static function get_options() {
		$opt = get_option(self::OPT, array());
		$def = self::default_options();
		if (!is_array($opt)) { $opt = array(); }
		$merged = array_merge($def, $opt);

		// Ensure mail_field_order is array
		if (!isset($merged['mail_field_order']) || !is_array($merged['mail_field_order'])) {
			$merged['mail_field_order'] = $def['mail_field_order'];
		}
		return $merged;
	}

	public static function update_options($new) {
		$def = self::default_options();
		$opt = self::get_options();

		// Whitelist keys
		$clean = array();
		foreach ($def as $k => $v) {
			if (isset($new[$k])) {
				$clean[$k] = $new[$k];
			} else {
				$clean[$k] = $opt[$k];
			}
		}

		// Basic sanitize
		$clean['events_slug'] = sanitize_title($clean['events_slug']);
		if ($clean['events_slug'] === '') { $clean['events_slug'] = 'events'; }

		$clean['default_mail_to'] = sanitize_text_field($clean['default_mail_to']);
		$clean['default_subject_tpl'] = sanitize_text_field($clean['default_subject_tpl']);

		$clean['default_booking_url'] = esc_url_raw($clean['default_booking_url']);
		if ($clean['default_booking_url'] === '') { $clean['default_booking_url'] = 'https://tdans.se/event'; }

		$allowed_reg = array('0','OPEN_FOR_REG','PUBLIC','NONE_EXPIRED','NOT_YET_SHOWN');
		$clean['dans_reg_status'] = sanitize_text_field($clean['dans_reg_status']);
		if (!in_array($clean['dans_reg_status'], $allowed_reg, true)) { $clean['dans_reg_status'] = 'NONE_EXPIRED'; }

		$clean['fallback_image_url'] = esc_url_raw($clean['fallback_image_url']);
		if ($clean['fallback_image_url'] === '') { $clean['fallback_image_url'] = 'https://media.tdans.se/2025/11/tdlogosmall-e1660139591215-2.avif'; }

		$allowed_date_modes = array('human_long','iso','slash','short_month','custom');
		if (!in_array($clean['date_format_mode'], $allowed_date_modes, true)) { $clean['date_format_mode'] = 'human_long'; }
		$clean['date_format_custom'] = sanitize_text_field($clean['date_format_custom']);

		$allowed_time_modes = array('start_end','start_only','custom');
		if (!in_array($clean['time_format_mode'], $allowed_time_modes, true)) { $clean['time_format_mode'] = 'start_end'; }
		$clean['time_format_custom'] = sanitize_text_field($clean['time_format_custom']);

		$clean['attach_cover'] = !empty($clean['attach_cover']) ? 1 : 0;

		// Defaults for creating events
		$clean['default_city_option'] = sanitize_text_field($clean['default_city_option']);
		$clean['default_city_other'] = sanitize_text_field($clean['default_city_other']);
		$clean['default_location_option'] = sanitize_text_field($clean['default_location_option']);
		$clean['default_location_other'] = sanitize_text_field($clean['default_location_other']);

		$clean['default_start_time'] = self::sanitize_time_hhmm($clean['default_start_time']);
		$clean['default_end_time']   = self::sanitize_time_hhmm($clean['default_end_time']);

		// Fetch group ids
		$clean['fetch_primary_group_ids'] = sanitize_text_field($clean['fetch_primary_group_ids']);
		$clean['fetch_group_ids'] = ''; // Back-compat (används inte)

		// mail_field_order: allow only known fields
		$known = self::known_mail_fields();
		$order = array();
		if (isset($new['mail_field_order_json'])) {
			$decoded = json_decode(stripslashes($new['mail_field_order_json']), true);
			if (is_array($decoded)) {
				foreach ($decoded as $f) {
					if (isset($known[$f])) { $order[] = $f; }
				}
			}
		}
		if (count($order) === 0) { $order = $def['mail_field_order']; }
		$clean['mail_field_order'] = $order;

		update_option(self::OPT, $clean);
	}

	public static function known_mail_fields() {
		return array(
			'cover_url' => 'Coverlänk (URL)',
			'title'     => 'Rubrik (Title)',
			'content'   => 'Text (Post content)',
			'date'      => 'Datum',
			'time'      => 'Tid',
			'location'  => 'Plats (text)',
		);
	}

	// -------------------------------------------------------------------------
	// Activation / Cron
	// -------------------------------------------------------------------------
	public static function on_activate() {
		// Ensure options exist
		if (!get_option(self::OPT)) {
			update_option(self::OPT, self::default_options());
		}

		// Register CPT now so rewrite works
		self::register_cpt();
		flush_rewrite_rules();

		// Schedule cron (every 5 minutes)
		if (!wp_next_scheduled(self::CRON_HOOK)) {
			wp_schedule_event(time() + 60, 'tnu_fbevent_5min', self::CRON_HOOK);
		}
	}

	public static function on_deactivate() {
		$ts = wp_next_scheduled(self::CRON_HOOK);
		if ($ts) {
			wp_unschedule_event($ts, self::CRON_HOOK);
		}
		flush_rewrite_rules();
	}

	public static function cron_schedules($schedules) {
		if (!isset($schedules['tnu_fbevent_5min'])) {
			$schedules['tnu_fbevent_5min'] = array(
				'interval' => 300,
				'display'  => 'TNU FB Event 5 minutes',
			);
		}
		return $schedules;
	}

	// -------------------------------------------------------------------------
	// CPT
	// -----------------------------------------------------------------------------
	public static function register_cpt() {
		$opt = self::get_options();
		$slug = $opt['events_slug'];

		$labels = array(
			'name'               => 'Events',
			'singular_name'      => 'Event',
			'menu_name'          => 'Events',
			'add_new'            => 'Lägg till nytt',
			'add_new_item'       => 'Lägg till nytt event',
			'edit_item'          => 'Redigera event',
			'new_item'           => 'Nytt event',
			'view_item'          => 'Visa event',
			'search_items'       => 'Sök events',
			'not_found'          => 'Inga events hittades',
			'not_found_in_trash' => 'Inga events i papperskorgen',
		);

		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'has_archive'        => true,
			'rewrite'            => array('slug' => $slug, 'with_front' => false),
			'supports'           => array('title','editor','thumbnail','excerpt'),
			'show_in_rest'       => true,
			'menu_position'      => 26,
			// Show under TNU menu if possible
			'show_in_menu'       => self::MENU_ROOT_SLUG,
		);

		register_post_type(self::CPT, $args);
	}

	public static function filter_event_permalink($permalink, $post) {
		if ($post->post_type !== self::CPT) { return $permalink; }
		return $permalink;
	}

	// -------------------------------------------------------------------------
	// Admin menu
	// -----------------------------------------------------------------------------
	public static function register_admin_menu() {
		global $menu;

		$root_exists = false;
		if (is_array($menu)) {
			foreach ($menu as $m) {
				if (!empty($m[2]) && $m[2] === self::MENU_ROOT_SLUG) {
					$root_exists = true;
					break;
				}
			}
		}

		if (!$root_exists) {
			add_menu_page(
				'TNU',
				'TNU',
				'manage_options',
				self::MENU_ROOT_SLUG,
				array(__CLASS__, 'render_plan_page'),
				'dashicons-admin-generic',
				58
			);
		}

		add_submenu_page(
			self::MENU_ROOT_SLUG,
			'TNU FB Event list/plan',
			'TNU FB Event list/plan',
			'manage_options',
			self::MENU_PLAN_SLUG,
			array(__CLASS__, 'render_plan_page')
		);

		add_submenu_page(
			self::MENU_ROOT_SLUG,
			'TNU Event fetch',
			'TNU Event fetch',
			'manage_options',
			self::MENU_FETCH_SLUG,
			array(__CLASS__, 'render_fetch_page')
		);

		add_submenu_page(
			self::MENU_ROOT_SLUG,
			'TNU Event Settings',
			'TNU Event Settings',
			'manage_options',
			self::MENU_SETTINGS_SLUG,
			array(__CLASS__, 'render_settings_page')
		);
	}

	public static function admin_assets($hook) {
		$is_our_page = (strpos($hook, self::MENU_PLAN_SLUG) !== false) || (strpos($hook, self::MENU_SETTINGS_SLUG) !== false) || (strpos($hook, self::MENU_FETCH_SLUG) !== false);

		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		$is_event_edit = ($screen && $screen->post_type === self::CPT);

		if (!$is_our_page && !$is_event_edit) { return; }

		wp_enqueue_style('tnu-fbevent-admin', TNU_FBEVENT_PLUGIN_URL . 'assets/admin.css', array(), TNU_FBEVENT_VERSION);
		wp_enqueue_script('tnu-fbevent-admin', TNU_FBEVENT_PLUGIN_URL . 'assets/admin.js', array('jquery','jquery-ui-sortable'), TNU_FBEVENT_VERSION, true);

		if ($is_event_edit) {
			wp_enqueue_media();
		}

		$opt = self::get_options();
		wp_localize_script('tnu-fbevent-admin', 'TNU_FBEVENT', array(
			'nonce' => wp_create_nonce('tnu_fbevent_nonce'),
			'ajaxUrl' => admin_url('admin-ajax.php'),
			'mailFieldOrder' => $opt['mail_field_order'],
		));
	}

	// -------------------------------------------------------------------------
	// Metaboxes
	// -----------------------------------------------------------------------------
	public static function register_metaboxes() {
		add_meta_box(
			'tnu_event_mail',
			'TNU Event – Mail (copy/paste)',
			array(__CLASS__, 'render_metabox_mail'),
			self::CPT,
			'normal',
			'high'
		);

		add_meta_box(
			'tnu_event_actions',
			'TNU Event – Åtgärder',
			array(__CLASS__, 'render_metabox_actions'),
			self::CPT,
			'side',
			'high'
		);

		add_meta_box(
			'tnu_event_dans_fetch',
			'TNU Event – Hämta från Dans.se',
			array(__CLASS__, 'render_metabox_dans_fetch'),
			self::CPT,
			'side',
			'high'
		);
	}

	public static function render_details_above_editor($post) {
		if (!$post || $post->post_type !== self::CPT) { return; }
		?>
		<div class="postbox tnu-postbox">
			<h2 class="hndle"><span>TNU Event – Detaljer</span></h2>
			<div class="inside">
				<?php self::render_details_fields($post); ?>
			</div>
		</div>
		<?php
	}

	public static function render_details_fields($post) {
		wp_nonce_field('tnu_event_save', 'tnu_event_nonce');
		$opt = self::get_options();

		$def_city_opt = $opt['default_city_option'];
		$def_city_other = $opt['default_city_other'];
		$def_loc_opt = $opt['default_location_option'];
		$def_loc_other = $opt['default_location_other'];
		$def_booking = $opt['default_booking_url'];
		$def_st = $opt['default_start_time'];
		$def_et = $opt['default_end_time'];

		$city_opt     = get_post_meta($post->ID, self::META_CITY_OPTION, true);
		$city_other   = get_post_meta($post->ID, self::META_CITY_OTHER, true);
		$loc_opt      = get_post_meta($post->ID, self::META_LOCATION_OPTION, true);
		$loc_other    = get_post_meta($post->ID, self::META_LOCATION_OTHER, true);

		$start_date   = get_post_meta($post->ID, self::META_START_DATE, true);
		$start_time   = get_post_meta($post->ID, self::META_START_TIME, true);
		$end_time     = get_post_meta($post->ID, self::META_END_TIME, true);
		$deadline_at  = get_post_meta($post->ID, self::META_DEADLINE_AT, true);
		$booking_url  = get_post_meta($post->ID, self::META_BOOKING_URL, true);

		$cover_id     = intval(get_post_meta($post->ID, self::META_COVER_IMAGE_ID, true));
		$cover_url    = get_post_meta($post->ID, self::META_COVER_IMAGE_URL, true);

		$is_new = ($post->post_status === 'auto-draft');
		if ($is_new) {
			if ($city_opt == '') { $city_opt = $def_city_opt; }
			if ($city_other == '') { $city_other = $def_city_other; }
			if ($loc_opt == '') { $loc_opt = $def_loc_opt; }
			if ($loc_other == '') { $loc_other = $def_loc_other; }
			if ($booking_url == '') { $booking_url = $def_booking; }
			if ($start_time == '') { $start_time = $def_st; }
			if ($end_time == '') { $end_time = $def_et; }
		}

		$cover_url_effective = '';
		if ($cover_id) {
			$cover_url_effective = wp_get_attachment_url($cover_id);
		} else if ($cover_url) {
			$cover_url_effective = $cover_url;
		}
		?>
		<table class="form-table">
			<tr>
				<th><label for="tnu_event_city_option">Ort</label></th>
				<td>
					<select id="tnu_event_city_option" name="tnu_event_city_option">
						<option value="norrkoping" <?php selected($city_opt, 'norrkoping'); ?>>Norrköping</option>
						<option value="nykoping" <?php selected($city_opt, 'nykoping'); ?>>Nyköping</option>
						<option value="other" <?php selected($city_opt, 'other'); ?>>Annan</option>
					</select>
					<input type="text" id="tnu_event_city_other" name="tnu_event_city_other" value="<?php echo esc_attr($city_other); ?>" class="regular-text" placeholder="Skriv ort..." style="max-width:280px; margin-left:8px;" />
				</td>
			</tr>

			<tr>
				<th><label for="tnu_event_location_option">Plats</label></th>
				<td>
					<select id="tnu_event_location_option" name="tnu_event_location_option">
						<option value="borgen" <?php selected($loc_opt, 'borgen'); ?>>Borgen</option>
						<option value="sunlight_hotel" <?php selected($loc_opt, 'sunlight_hotel'); ?>>Sunlight Hotel</option>
						<option value="sunlight_gymspa" <?php selected($loc_opt, 'sunlight_gymspa'); ?>>Sunlight Gym &amp; SPA</option>
						<option value="other" <?php selected($loc_opt, 'other'); ?>>Annan</option>
					</select>
					<input type="text" id="tnu_event_location_other" name="tnu_event_location_other" value="<?php echo esc_attr($loc_other); ?>" class="regular-text" placeholder="Skriv plats..." style="max-width:380px; margin-left:8px;" />
				</td>
			</tr>

			<tr>
				<th><label for="tnu_event_start_date">Datum (YYYY-MM-DD)</label></th>
				<td>
					<input type="date" id="tnu_event_start_date" name="tnu_event_start_date" value="<?php echo esc_attr($start_date); ?>" />
					<p class="description">Slug-regel (vid save): &lt;titel&gt;-&lt;ort&gt;-YYYY-MM-DD</p>
				</td>
			</tr>

			<tr>
				<th><label for="tnu_event_start_time">Starttid (24h)</label></th>
				<td><input type="time" id="tnu_event_start_time" name="tnu_event_start_time" value="<?php echo esc_attr($start_time); ?>" /></td>
			</tr>

			<tr>
				<th><label for="tnu_event_end_time">Sluttid (24h)</label></th>
				<td><input type="time" id="tnu_event_end_time" name="tnu_event_end_time" value="<?php echo esc_attr($end_time); ?>" /></td>
			</tr>

			<tr>
				<th><label for="tnu_event_deadline_at">Deadline</label></th>
				<td>
					<input type="datetime-local" id="tnu_event_deadline_at" name="tnu_event_deadline_at" value="<?php echo esc_attr(self::to_datetime_local($deadline_at)); ?>" />
					<p class="description">Lagrar som: YYYY-MM-DD HH:MM</p>
				</td>
			</tr>

			<tr>
				<th><label for="tnu_event_booking_url">Bokningslänk</label></th>
				<td>
					<input type="url" id="tnu_event_booking_url" name="tnu_event_booking_url" value="<?php echo esc_attr($booking_url); ?>" class="regular-text" />
					<p class="description">Default finns i Settings och kan ändras här per event.</p>
				</td>
			</tr>

			<tr>
				<th><label for="tnu_event_cover_image_id">Coverbild (Media)</label></th>
				<td>
					<input type="hidden" id="tnu_event_cover_image_id" name="tnu_event_cover_image_id" value="<?php echo esc_attr($cover_id); ?>" />
					<input type="hidden" id="tnu_event_cover_image_url" name="tnu_event_cover_image_url" value="<?php echo esc_attr($cover_url); ?>" />
					<button type="button" class="button" id="tnu_event_cover_pick">Välj bild</button>
					<button type="button" class="button" id="tnu_event_cover_clear">Rensa</button>

					<div class="tnu-cover-preview" style="margin-top:10px;">
						<?php if ($cover_url_effective): ?>
							<p><strong>URL:</strong> <a id="tnu_cover_url_link" href="<?php echo esc_url($cover_url_effective); ?>" target="_blank" rel="noopener"><?php echo esc_html($cover_url_effective); ?></a></p>
							<img id="tnu_cover_img" src="<?php echo esc_url($cover_url_effective); ?>" style="max-width: 520px; width:100%; height: auto;" />
						<?php else: ?>
							<p class="description" id="tnu_cover_none">Ingen bild vald.</p>
							<p style="display:none;"><strong>URL:</strong> <a id="tnu_cover_url_link" href="#" target="_blank" rel="noopener"></a></p>
							<img id="tnu_cover_img" src="" style="display:none; max-width: 520px; width:100%; height: auto;" />
						<?php endif; ?>
					</div>

					<p class="description" style="margin-top:10px;">Tips: När du hämtar från Dans.se importeras cover till Media om profileImageUrl finns – annars hoppas den över.</p>
				</td>
			</tr>
		</table>

		<script>
		(function($){
			$(function(){
				function toggleOtherFields(){
					var cityOpt = $('#tnu_event_city_option').val();
					$('#tnu_event_city_other').prop('disabled', cityOpt !== 'other');
					var locOpt = $('#tnu_event_location_option').val();
					$('#tnu_event_location_other').prop('disabled', locOpt !== 'other');
				}
				$('#tnu_event_city_option, #tnu_event_location_option').on('change', toggleOtherFields);
				toggleOtherFields();

				var frame;
				$('#tnu_event_cover_pick').on('click', function(e){
					e.preventDefault();
					if (frame) { frame.open(); return; }
					frame = wp.media({
						title: 'Välj coverbild',
						button: { text: 'Använd bild' },
						multiple: false
					});
					frame.on('select', function(){
						var attachment = frame.state().get('selection').first().toJSON();
						$('#tnu_event_cover_image_id').val(attachment.id);
						$('#tnu_event_cover_image_url').val('');

						var url = attachment.url || '';
						if (url) {
							$('#tnu_cover_none').hide();
							$('#tnu_cover_url_link').attr('href', url).text(url).closest('p').show();
							$('#tnu_cover_img').attr('src', url).show();
						}
					});
					frame.open();
				});

				$('#tnu_event_cover_clear').on('click', function(e){
					e.preventDefault();
					$('#tnu_event_cover_image_id').val('');
					$('#tnu_event_cover_image_url').val('');
					$('#tnu_cover_img').attr('src','').hide();
					$('#tnu_cover_url_link').attr('href','#').text('').closest('p').hide();
					$('#tnu_cover_none').show();
				});
			});
		})(jQuery);
		</script>
		<?php
	}

	public static function render_metabox_dans_fetch($post) {
		$dans_id = get_post_meta($post->ID, self::META_DANS_EVENT_ID, true);
		?>
		<p>
			<label for="tnu_dans_event_id"><strong>Dans.se Event ID</strong></label><br/>
			<input type="number" min="1" id="tnu_dans_event_id" name="tnu_dans_event_id" value="<?php echo esc_attr($dans_id); ?>" style="width: 100%;" placeholder="t.ex. 261988" />
		</p>

		<p>
			<button type="button" class="button button-primary" id="tnu_dans_fetch_btn" data-postid="<?php echo esc_attr($post->ID); ?>">
				Hämta från Dans.se
			</button>
		</p>

		<div id="tnu_dans_fetch_status" class="tnu-fetch-status" style="margin-top:10px;"></div>

		<p class="description">
			Regel 1: Datum/tid = schedule.start.date + schedule.start.time. Sluttid = schedule.end.time.
			Cover importeras till Media om profileImageUrl finns – annars hoppas den över.
		</p>
		<?php
	}

	public static function render_metabox_mail($post) {
		$mail_at = get_post_meta($post->ID, self::META_MAIL_AT, true);
		$mail_sent_at = get_post_meta($post->ID, self::META_MAIL_SENT_AT, true);
		$to_override = get_post_meta($post->ID, self::META_MAIL_TO_OVERRIDE, true);
		$subject_override = get_post_meta($post->ID, self::META_SUBJECT_OVERRIDE, true);

		$preview = self::build_mail_preview($post->ID, false);
		$subject_preview = self::build_subject($post->ID);
		?>
		<table class="form-table">
			<tr>
				<th><label for="tnu_event_mail_at">Skicka mail vid</label></th>
				<td>
					<input type="datetime-local" id="tnu_event_mail_at" name="tnu_event_mail_at" value="<?php echo esc_attr(self::to_datetime_local($mail_at)); ?>" />
					<p class="description">Lagrar som: YYYY-MM-DD HH:MM (WP-Cron var 5:e minut)</p>
				</td>
			</tr>
			<tr>
				<th><label for="tnu_event_mail_to_override">Mottagare</label></th>
				<td>
					<input type="text" id="tnu_event_mail_to_override" name="tnu_event_mail_to_override" value="<?php echo esc_attr($to_override); ?>" class="regular-text" placeholder="tommy@... , info@..." />
				</td>
			</tr>
			<tr>
				<th><label for="tnu_event_subject_override">Ämnesrad</label></th>
				<td>
					<input type="text" id="tnu_event_subject_override" name="tnu_event_subject_override" value="<?php echo esc_attr($subject_override); ?>" class="regular-text" placeholder="{date} – {city} – {title}" />
					<p class="description">Variabler: {title}, {city}, {date}</p>
				</td>
			</tr>
			<tr>
				<th>Ämnesrad – förhandsvisning</th>
				<td><code><?php echo esc_html($subject_preview); ?></code></td>
			</tr>
			<tr>
				<th>Mail – förhandsvisning</th>
				<td>
					<textarea readonly rows="12" style="width:100%; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;"><?php echo esc_textarea($preview); ?></textarea>
				</td>
			</tr>
			<tr>
				<th>Senast skickat</th>
				<td>
					<?php if ($mail_sent_at): ?>
						<strong><?php echo esc_html(date_i18n('Y-m-d H:i', intval($mail_sent_at))); ?></strong>
					<?php else: ?>
						<span class="description">Inte skickat ännu.</span>
					<?php endif; ?>
				</td>
			</tr>
		</table>
		<?php
	}

	public static function render_metabox_actions($post) {
		$send_test_url = wp_nonce_url(admin_url('admin-post.php?action=tnu_fbevent_send_test&post_id=' . intval($post->ID)), 'tnu_fbevent_send_test_' . intval($post->ID));
		$resend_url    = wp_nonce_url(admin_url('admin-post.php?action=tnu_fbevent_resend&post_id=' . intval($post->ID)), 'tnu_fbevent_resend_' . intval($post->ID));
		$copy_url      = wp_nonce_url(admin_url('admin-post.php?action=tnu_fbevent_copy_new&post_id=' . intval($post->ID)), 'tnu_fbevent_copy_new_' . intval($post->ID));
		?>
		<p><a class="button button-primary" href="<?php echo esc_url($send_test_url); ?>">Skicka testmail nu</a></p>
		<p><a class="button" href="<?php echo esc_url($resend_url); ?>" onclick="return confirm('Skicka om mail nu? Detta skickar direkt.');">Skicka om mail</a></p>
		<p><a class="button" href="<?php echo esc_url($copy_url); ?>" onclick="return confirm('Kopiera till nytt event? (Datum och mailtid nollställs, tider kopieras)');">Kopiera till ny</a></p>
		<?php
	}

	public static function save_event_metaboxes($post_id, $post) {
		if ($post->post_type !== self::CPT) { return; }
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
		if (!isset($_POST['tnu_event_nonce']) || !wp_verify_nonce($_POST['tnu_event_nonce'], 'tnu_event_save')) { return; }
		if (!current_user_can('edit_post', $post_id)) { return; }

		$city_opt    = isset($_POST['tnu_event_city_option']) ? sanitize_text_field($_POST['tnu_event_city_option']) : '';
		$city_other  = isset($_POST['tnu_event_city_other']) ? sanitize_text_field($_POST['tnu_event_city_other']) : '';
		$loc_opt     = isset($_POST['tnu_event_location_option']) ? sanitize_text_field($_POST['tnu_event_location_option']) : '';
		$loc_other   = isset($_POST['tnu_event_location_other']) ? sanitize_text_field($_POST['tnu_event_location_other']) : '';

		$start_date  = isset($_POST['tnu_event_start_date']) ? sanitize_text_field($_POST['tnu_event_start_date']) : '';
		$start_time  = isset($_POST['tnu_event_start_time']) ? sanitize_text_field($_POST['tnu_event_start_time']) : '';
		$end_time    = isset($_POST['tnu_event_end_time']) ? sanitize_text_field($_POST['tnu_event_end_time']) : '';

		$deadline_at = isset($_POST['tnu_event_deadline_at']) ? sanitize_text_field($_POST['tnu_event_deadline_at']) : '';
		$booking_url = isset($_POST['tnu_event_booking_url']) ? esc_url_raw($_POST['tnu_event_booking_url']) : '';
		$cover_id    = isset($_POST['tnu_event_cover_image_id']) ? intval($_POST['tnu_event_cover_image_id']) : 0;
		$cover_url   = isset($_POST['tnu_event_cover_image_url']) ? esc_url_raw($_POST['tnu_event_cover_image_url']) : '';

		$mail_at     = isset($_POST['tnu_event_mail_at']) ? sanitize_text_field($_POST['tnu_event_mail_at']) : '';
		$to_override = isset($_POST['tnu_event_mail_to_override']) ? sanitize_text_field($_POST['tnu_event_mail_to_override']) : '';
		$subject_ovr = isset($_POST['tnu_event_subject_override']) ? sanitize_text_field($_POST['tnu_event_subject_override']) : '';

		$dans_id     = isset($_POST['tnu_dans_event_id']) ? sanitize_text_field($_POST['tnu_dans_event_id']) : '';

		update_post_meta($post_id, self::META_CITY_OPTION, $city_opt);
		update_post_meta($post_id, self::META_CITY_OTHER, $city_other);

		update_post_meta($post_id, self::META_LOCATION_OPTION, $loc_opt);
		update_post_meta($post_id, self::META_LOCATION_OTHER, $loc_other);

		update_post_meta($post_id, self::META_START_DATE, $start_date);
		update_post_meta($post_id, self::META_START_TIME, self::sanitize_time_hhmm($start_time));
		update_post_meta($post_id, self::META_END_TIME, self::sanitize_time_hhmm($end_time));

		update_post_meta($post_id, self::META_BOOKING_URL, $booking_url);

		update_post_meta($post_id, self::META_COVER_IMAGE_ID, $cover_id);
		if ($cover_id) {
			update_post_meta($post_id, self::META_COVER_IMAGE_URL, '');
		} else {
			update_post_meta($post_id, self::META_COVER_IMAGE_URL, $cover_url);
		}

		$deadline_clean = self::from_datetime_local($deadline_at);
		update_post_meta($post_id, self::META_DEADLINE_AT, $deadline_clean);

		$mail_clean = self::from_datetime_local($mail_at);
		update_post_meta($post_id, self::META_MAIL_AT, $mail_clean);

		update_post_meta($post_id, self::META_MAIL_TO_OVERRIDE, $to_override);
		update_post_meta($post_id, self::META_SUBJECT_OVERRIDE, $subject_ovr);

		update_post_meta($post_id, self::META_DANS_EVENT_ID, $dans_id);

		$city_display = self::get_city_display($post_id);
		self::apply_slug_rule($post_id, $post->post_title, $city_display, $start_date);
	}

	public static function apply_slug_rule($post_id, $title, $city_display, $start_date) {
		if (empty($title) || empty($city_display) || empty($start_date)) { return; }
		$date = preg_replace('/[^0-9\\-]/', '', $start_date);
		if (!preg_match('/^\\d{4}\\-\\d{2}\\-\\d{2}$/', $date)) { return; }

		$raw = sanitize_title($title . '-' . $city_display . '-' . $date);
		$unique = wp_unique_post_slug($raw, $post_id, 'publish', self::CPT, 0);

		$post = get_post($post_id);
		if ($post && $post->post_name !== $unique) {
			remove_action('save_post', array(__CLASS__, 'save_event_metaboxes'), 10);
			wp_update_post(array('ID' => $post_id, 'post_name' => $unique));
			add_action('save_post', array(__CLASS__, 'save_event_metaboxes'), 10, 2);
		}
	}

	// -------------------------------------------------------------------------
	// Admin pages
	// -----------------------------------------------------------------------------
	public static function render_plan_page() {
		if (!current_user_can('manage_options')) { return; }

		$opt = self::get_options();

		$q = new WP_Query(array(
			'post_type'      => self::CPT,
			'post_status'    => array('publish','future','draft'),
			'posts_per_page' => 50,
			'orderby'        => 'date',
			'order'          => 'DESC',
		));
		?>
		<div class="wrap">
			<h1>TNU FB Event list/plan</h1>

			<div class="tnu-box">
				<p><strong>Events slug:</strong> <code><?php echo esc_html($opt['events_slug']); ?></code> → <a href="<?php echo esc_url(home_url('/' . $opt['events_slug'] . '/')); ?>" target="_blank" rel="noopener">Öppna /<?php echo esc_html($opt['events_slug']); ?>/</a></p>
				<p><strong>Default bokningslänk:</strong> <code><?php echo esc_html($opt['default_booking_url']); ?></code></p>
				<p><strong>WP-Cron:</strong> kör var 5:e minut (tills vidare).</p>
			</div>

			<table class="widefat striped">
				<thead>
					<tr>
						<th>Titel</th>
						<th>Ort</th>
						<th>Datum</th>
						<th>Tid</th>
						<th>Mail vid</th>
						<th>Mail skickat</th>
						<th>Dans.se ID</th>
					</tr>
				</thead>
				<tbody>
				<?php if ($q->have_posts()): while ($q->have_posts()): $q->the_post();
					$id = get_the_ID();
					$title = get_the_title();
					$edit = get_edit_post_link($id);

					$city = self::get_city_display($id);
					$sd   = get_post_meta($id, self::META_START_DATE, true);
					$st   = get_post_meta($id, self::META_START_TIME, true);
					$et   = get_post_meta($id, self::META_END_TIME, true);

					$mail_at = get_post_meta($id, self::META_MAIL_AT, true);
					$mail_sent_at = get_post_meta($id, self::META_MAIL_SENT_AT, true);

					$dans_id = get_post_meta($id, self::META_DANS_EVENT_ID, true);
					?>
					<tr>
						<td><a href="<?php echo esc_url($edit); ?>"><strong><?php echo esc_html($title); ?></strong></a></td>
						<td><?php echo esc_html($city); ?></td>
						<td><?php echo esc_html($sd); ?></td>
						<td><?php echo esc_html(self::format_time_display($st, $et)); ?></td>
						<td><?php echo esc_html($mail_at); ?></td>
						<td><?php echo $mail_sent_at ? esc_html(date_i18n('Y-m-d H:i', intval($mail_sent_at))) : '-'; ?></td>
						<td><?php echo esc_html($dans_id); ?></td>
					</tr>
				<?php endwhile; wp_reset_postdata(); else: ?>
					<tr><td colspan="7">Inga events hittades.</td></tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function render_settings_page() {
		if (!current_user_can('manage_options')) { return; }

		$opt = self::get_options();
		$known = self::known_mail_fields();

		if (isset($_POST['tnu_fbevent_save_settings'])) {
			check_admin_referer('tnu_fbevent_save_settings', 'tnu_fbevent_settings_nonce');
			self::update_options($_POST);
			$opt = self::get_options();
			echo '<div class="notice notice-success is-dismissible"><p>Inställningar sparade.</p></div>';
		}
		?>
		<div class="wrap">
			<h1>TNU Event Settings</h1>

			<form method="post">
				<?php wp_nonce_field('tnu_fbevent_save_settings', 'tnu_fbevent_settings_nonce'); ?>

				<table class="form-table">
					<tr>
						<th><label for="default_booking_url">Default bokningslänk</label></th>
						<td><input type="url" id="default_booking_url" name="default_booking_url" value="<?php echo esc_attr($opt['default_booking_url']); ?>" class="regular-text" /></td>
					</tr>


					<tr>
						<th><label for="dans_reg_status">Dans.se regStatus</label></th>
						<td>
							<select id="dans_reg_status" name="dans_reg_status">
								<?php
								$reg_items = array(
									'0'            => '0',
									'OPEN_FOR_REG' => 'OPEN_FOR_REG',
									'PUBLIC'       => 'PUBLIC',
									'NONE_EXPIRED' => 'NONE_EXPIRED',
									'NOT_YET_SHOWN'=> 'NOT_YET_SHOWN',
								);
								foreach ($reg_items as $k => $label) {
									echo '<option value="'.esc_attr($k).'" '.selected($opt['dans_reg_status'], $k, false).'>'.esc_html($label).'</option>';
								}
								?>
							</select>
							<p class="description">Styr Dans.se URL-parametern regStatus.</p>
						</td>
					</tr>

					<tr>
						<th><label for="fallback_image_url">Fallback-bild (URL)</label></th>
						<td>
							<input type="url" id="fallback_image_url" name="fallback_image_url" value="<?php echo esc_attr($opt['fallback_image_url']); ?>" class="regular-text" />
							<p class="description">Används som cover/featured image om event saknar bild. Default: https://media.tdans.se/2025/11/tdlogosmall-e1660139591215-2.avif</p>
						</td>
					</tr>

					<tr>
						<th><label for="fetch_primary_group_ids">Fetch: PrimaryEventGroup ID (kommaseparerat) (primaryEventGroup-id eller eventBlock-id)</label></th>
						<td>
							<textarea id="fetch_primary_group_ids" name="fetch_primary_group_ids" rows="2" class="large-text" placeholder="3672,18336"><?php echo esc_textarea($opt['fetch_primary_group_ids']); ?></textarea>
							<p class="description">Komma-separerat. Använd id från primaryEventGroup.id och/eller grouping.eventBlock.id. Dessa styr vad som listas i “TNU Event fetch”.</p>
						</td>
					</tr>

					<tr>
						<th><label for="default_city_option">Default ort</label></th>
						<td>
							<select id="default_city_option" name="default_city_option">
								<option value="norrkoping" <?php selected($opt['default_city_option'], 'norrkoping'); ?>>Norrköping</option>
								<option value="nykoping" <?php selected($opt['default_city_option'], 'nykoping'); ?>>Nyköping</option>
								<option value="other" <?php selected($opt['default_city_option'], 'other'); ?>>Annan</option>
							</select>
							<input type="text" name="default_city_other" value="<?php echo esc_attr($opt['default_city_other']); ?>" class="regular-text" placeholder="Om Annan: skriv ort..." style="max-width:280px; margin-left:8px;" />
						</td>
					</tr>

					<tr>
						<th><label for="default_location_option">Default plats</label></th>
						<td>
							<select id="default_location_option" name="default_location_option">
								<option value="borgen" <?php selected($opt['default_location_option'], 'borgen'); ?>>Borgen</option>
								<option value="sunlight_hotel" <?php selected($opt['default_location_option'], 'sunlight_hotel'); ?>>Sunlight Hotel</option>
								<option value="sunlight_gymspa" <?php selected($opt['default_location_option'], 'sunlight_gymspa'); ?>>Sunlight Gym &amp; SPA</option>
								<option value="other" <?php selected($opt['default_location_option'], 'other'); ?>>Annan</option>
							</select>
							<input type="text" name="default_location_other" value="<?php echo esc_attr($opt['default_location_other']); ?>" class="regular-text" placeholder="Om Annan: skriv plats..." style="max-width:380px; margin-left:8px;" />
						</td>
					</tr>

					<tr>
						<th>Default tider (24h)</th>
						<td>
							<label>Start <input type="time" name="default_start_time" value="<?php echo esc_attr($opt['default_start_time']); ?>" /></label>
							&nbsp;&nbsp;
							<label>Slut <input type="time" name="default_end_time" value="<?php echo esc_attr($opt['default_end_time']); ?>" /></label>
						</td>
					</tr>

					<tr>
						<th><label for="default_mail_to">Default mottagare</label></th>
						<td><input type="text" id="default_mail_to" name="default_mail_to" value="<?php echo esc_attr($opt['default_mail_to']); ?>" class="regular-text" /></td>
					</tr>

					<tr>
						<th><label for="default_subject_tpl">Default ämnesrad</label></th>
						<td>
							<input type="text" id="default_subject_tpl" name="default_subject_tpl" value="<?php echo esc_attr($opt['default_subject_tpl']); ?>" class="regular-text" />
							<p class="description">Variabler: {title}, {city}, {date}</p>
						</td>
					</tr>

					<tr>
						<th>Datumformat i mail</th>
						<td>
							<select name="date_format_mode">
								<option value="human_long" <?php selected($opt['date_format_mode'], 'human_long'); ?>>31 oktober 2026</option>
								<option value="iso" <?php selected($opt['date_format_mode'], 'iso'); ?>>2026-10-31</option>
								<option value="slash" <?php selected($opt['date_format_mode'], 'slash'); ?>>31/10/2026</option>
								<option value="short_month" <?php selected($opt['date_format_mode'], 'short_month'); ?>>31 okt 2026</option>
								<option value="custom" <?php selected($opt['date_format_mode'], 'custom'); ?>>Anpassat (PHP-format)</option>
							</select>
							<input type="text" name="date_format_custom" value="<?php echo esc_attr($opt['date_format_custom']); ?>" class="regular-text" />
						</td>
					</tr>

					<tr>
						<th>Tid i mail</th>
						<td>
							<select name="time_format_mode">
								<option value="start_end" <?php selected($opt['time_format_mode'], 'start_end'); ?>>Start–Slut</option>
								<option value="start_only" <?php selected($opt['time_format_mode'], 'start_only'); ?>>Endast start</option>
								<option value="custom" <?php selected($opt['time_format_mode'], 'custom'); ?>>Anpassat</option>
							</select>
							<input type="text" name="time_format_custom" value="<?php echo esc_attr($opt['time_format_custom']); ?>" class="regular-text" />
						</td>
					</tr>

					<tr>
						<th>Cover som bilaga</th>
						<td><label><input type="checkbox" name="attach_cover" value="1" <?php checked($opt['attach_cover'], 1); ?> /> Bifoga coverbild i mailet (lokal Media-fil)</label></td>
					</tr>

					<tr>
						<th>Mailfält – turordning</th>
						<td>
							<ul id="tnu-mail-field-sortable" class="tnu-sortable">
								<?php
								$order = $opt['mail_field_order'];
								foreach ($order as $f) {
									if (!isset($known[$f])) { continue; }
									echo '<li class="tnu-sortable-item" data-field="' . esc_attr($f) . '"><span class="dashicons dashicons-move"></span> ' . esc_html($known[$f]) . ' <code>' . esc_html($f) . '</code></li>';
								}
								foreach ($known as $f => $label) {
									if (!in_array($f, $order, true)) {
										echo '<li class="tnu-sortable-item" data-field="' . esc_attr($f) . '"><span class="dashicons dashicons-move"></span> ' . esc_html($label) . ' <code>' . esc_html($f) . '</code></li>';
									}
								}
								?>
							</ul>
							<input type="hidden" id="mail_field_order_json" name="mail_field_order_json" value="<?php echo esc_attr(wp_json_encode(array_values($opt['mail_field_order']))); ?>" />
						</td>
					</tr>
				</table>

				<p><button type="submit" name="tnu_fbevent_save_settings" class="button button-primary">Spara</button></p>
			</form>
		</div>
		<?php
	}

	public static function render_fetch_page() {
		if (!current_user_can('manage_options')) { return; }

		$opt = self::get_options();
		$group_ids = self::parse_group_ids($opt['fetch_primary_group_ids']);

		$events = self::dans_get_events_list_cached();

		$filtered = array();
		foreach ($events as $e) {
			$pegi = 0;
			if (isset($e['primaryEventGroup']['id'])) {
				$pegi = intval($e['primaryEventGroup']['id']);
			} else if (isset($e['grouping']['primaryEventGroup']['id'])) {
				$pegi = intval($e['grouping']['primaryEventGroup']['id']);
			}

			if (count($group_ids) === 0) {
				$filtered[] = $e;
			} else {
				if (in_array($pegi, $group_ids, true)) {
					$filtered[] = $e;
				}
			}
		}
		?>
		<div class="wrap">
			<h1>TNU Event fetch</h1>

			<div class="tnu-box">
				<p><strong>Filter</strong> (Settings → “Fetch: lista grupper”): <code><?php echo esc_html($opt['fetch_primary_group_ids']); ?></code></p>
				<p class="description">Listan visar events där primaryEventGroup.id (eller grouping.primaryEventGroup.id om den ligger där) matchar dina id:n. Endast detta filter används.</p>
			</div>

			<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
				<?php wp_nonce_field('tnu_fbevent_bulk_import', 'tnu_fbevent_bulk_import_nonce'); ?>
				<input type="hidden" name="action" value="tnu_fbevent_bulk_import" />

				<table class="widefat striped">
					<thead>
						<tr>
							<th style="width:36px;"><input type="checkbox" id="tnu_fetch_check_all" /></th>
							<th>Dans.se ID</th>
							<th>Namn</th>
							<th>Start</th>
							<th>Plats</th>
							<th>Grupper</th>
							<th>Redan importerad?</th>
						</tr>
					</thead>
					<tbody>
					<?php if (count($filtered) > 0): foreach ($filtered as $e):
						$id = isset($e['id']) ? intval($e['id']) : 0;
						$name = isset($e['name']) ? $e['name'] : '';
						$place = isset($e['place']) ? $e['place'] : '';
						$sd = isset($e['schedule']['start']['date']) ? $e['schedule']['start']['date'] : '';
						$st = isset($e['schedule']['start']['time']) ? $e['schedule']['start']['time'] : '';
						$start = trim($sd . ' ' . $st);

						$pegi = isset($e['primaryEventGroup']['id']) ? intval($e['primaryEventGroup']['id']) : 0;
						$pegn = isset($e['grouping']['primaryEventGroup']['name']) ? $e['grouping']['primaryEventGroup']['name'] : (isset($e['primaryEventGroup']['name']) ? $e['primaryEventGroup']['name'] : '');
						$blocki = isset($e['grouping']['eventBlock']['id']) ? intval($e['grouping']['eventBlock']['id']) : 0;
						$blockn = isset($e['grouping']['eventBlock']['name']) ? $e['grouping']['eventBlock']['name'] : '';

						$existing = self::find_post_id_by_dans_event_id($id);
						?>
						<tr>
							<td><input type="checkbox" class="tnu_fetch_chk" name="dans_ids[]" value="<?php echo esc_attr($id); ?>" /></td>
							<td><code><?php echo esc_html($id); ?></code></td>
							<td><?php echo esc_html($name); ?></td>
							<td><?php echo esc_html($start); ?></td>
							<td><?php echo esc_html($place); ?></td>
							<td>
								<?php if ($blocki): ?><div><strong>eventBlock:</strong> <?php echo esc_html($blockn); ?> <code><?php echo esc_html($blocki); ?></code></div><?php endif; ?>
								<?php if ($pegi): ?><div><strong>primaryEventGroup:</strong> <?php echo esc_html($pegn); ?> <code><?php echo esc_html($pegi); ?></code></div><?php endif; ?>
							</td>
							<td>
								<?php if ($existing): ?>
									<span class="tnu-badge tnu-badge-ok">Ja</span>
									<a href="<?php echo esc_url(get_edit_post_link($existing)); ?>">Öppna</a>
								<?php else: ?>
									<span class="tnu-badge tnu-badge-warn">Nej</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; else: ?>
						<tr><td colspan="7">Inga events matchar dina filter (eller API gav ingen lista).</td></tr>
					<?php endif; ?>
					</tbody>
				</table>

				<p style="margin-top:12px;">
					<button type="submit" class="button button-primary">Importera markerade</button>
					<span class="description" style="margin-left:10px;">Skapar CPT-events och importerar coverbild till Media om profileImageUrl finns. Om bild saknas → hoppar över.</span>
				</p>
			</form>
		</div>
		<?php
	}

	public static function handle_bulk_import() {
		if (!current_user_can('manage_options')) { wp_die('No access'); }
		if (!isset($_POST['tnu_fbevent_bulk_import_nonce']) || !wp_verify_nonce($_POST['tnu_fbevent_bulk_import_nonce'], 'tnu_fbevent_bulk_import')) {
			wp_die('Bad nonce');
		}

		$ids = isset($_POST['dans_ids']) && is_array($_POST['dans_ids']) ? array_map('intval', $_POST['dans_ids']) : array();
		if (count($ids) === 0) {
			wp_safe_redirect(wp_get_referer() ? wp_get_referer() : admin_url());
			exit;
		}

		$imported = 0;
		$updated = 0;
		$skipped = 0;

		foreach ($ids as $dans_id) {
			if ($dans_id <= 0) { continue; }

			$data = self::dans_get_event_by_id($dans_id);
			if (!$data) { $skipped++; continue; }

			$existing_id = self::find_post_id_by_dans_event_id($dans_id);
			if ($existing_id) {
				self::apply_dans_data_to_post($existing_id, $data, true);
				$updated++;
			} else {
				$new_id = wp_insert_post(array(
					'post_type'   => self::CPT,
					'post_status' => 'draft',
					'post_title'  => isset($data['name']) ? sanitize_text_field($data['name']) : ('Dans event ' . $dans_id),
					'post_content'=> '',
				));
				if ($new_id && !is_wp_error($new_id)) {
					update_post_meta($new_id, self::META_DANS_EVENT_ID, (string)$dans_id);
					self::apply_dans_data_to_post($new_id, $data, true);
					$imported++;
				} else {
					$skipped++;
				}
			}
		}

		$ref = wp_get_referer() ? wp_get_referer() : admin_url('admin.php?page=' . self::MENU_FETCH_SLUG);
		$ref = add_query_arg(array('imported'=>$imported,'updated'=>$updated,'skipped'=>$skipped), $ref);
		wp_safe_redirect($ref);
		exit;
	}

	// -------------------------------------------------------------------------
	// Shortcodes
	// -----------------------------------------------------------------------------
	public static function register_shortcodes() {
		add_shortcode('tdans_next_event_banner', array(__CLASS__, 'shortcode_next_event_banner'));
		add_shortcode('tdans_events_list', array(__CLASS__, 'shortcode_events_list'));
	}

	public static function shortcode_next_event_banner($atts) {
		$opt = self::get_options();
		$events_url = home_url('/' . $opt['events_slug'] . '/');

		$next = self::get_next_event();
		if (!$next) { return ''; }

		$id = $next->ID;
		$title = get_the_title($id);
		$city = self::get_city_display($id);

		$sd = get_post_meta($id, self::META_START_DATE, true);
		$st = get_post_meta($id, self::META_START_TIME, true);
		$et = get_post_meta($id, self::META_END_TIME, true);

		$booking = get_post_meta($id, self::META_BOOKING_URL, true);
		if ($booking == '') { $booking = $opt['default_booking_url']; }

		$date_disp = self::format_date_display($sd);
		$time_disp = self::format_time_display($st, $et);

		$link = get_permalink($id);
		$cta = $booking ? $booking : $link;

		ob_start();
		?>
		<div class="tnu-next-event-banner" style="border:1px solid #ddd; padding:12px; border-radius:10px; margin:12px 0;">
			<div style="display:flex; flex-wrap:wrap; align-items:center; gap:12px;">
				<div style="flex:1 1 260px;">
					<strong>Nästa event:</strong>
					<a href="<?php echo esc_url($link); ?>"><?php echo esc_html($title); ?></a>
					<?php if ($city): ?> – <span><?php echo esc_html($city); ?></span><?php endif; ?>
					<div style="margin-top:6px;">
						<span><?php echo esc_html($date_disp); ?></span>
						<?php if ($time_disp): ?> • <span><?php echo esc_html($time_disp); ?></span><?php endif; ?>
					</div>
				</div>
				<div style="display:flex; gap:10px; align-items:center;">
					<a class="button" href="<?php echo esc_url($cta); ?>">Läs mer / Boka</a>
					<a href="<?php echo esc_url($events_url); ?>">Se alla event</a>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	public static function shortcode_events_list($atts) {
		$opt = self::get_options();
		$atts = shortcode_atts(array('limit' => 20), $atts);

		$q = new WP_Query(array(
			'post_type'      => self::CPT,
			'post_status'    => array('publish','future'),
			'posts_per_page' => intval($atts['limit']),
			'meta_key'       => self::META_START_DATE,
			'orderby'        => 'meta_value',
			'order'          => 'ASC',
			'meta_query'     => array(
				array(
					'key'     => self::META_START_DATE,
					'value'   => date('Y-m-d', current_time('timestamp')),
					'compare' => '>=',
					'type'    => 'DATE',
				)
			),
		));

		if (!$q->have_posts()) { return '<p>Inga kommande event just nu.</p>'; }

		ob_start(); ?>
		<div class="tnu-events-list">
			<?php while ($q->have_posts()): $q->the_post(); $id = get_the_ID();
				$city = self::get_city_display($id);
				$sd = get_post_meta($id, self::META_START_DATE, true);
				$st = get_post_meta($id, self::META_START_TIME, true);
				$et = get_post_meta($id, self::META_END_TIME, true);
				$loc = self::get_location_display($id);

				$booking = get_post_meta($id, self::META_BOOKING_URL, true);
				if ($booking == '') { $booking = $opt['default_booking_url']; }

				$date_disp = self::format_date_display($sd);
				$time_disp = self::format_time_display($st, $et);
				?>
				<div class="tnu-event-card" style="border:1px solid #eee; padding:12px; border-radius:10px; margin:10px 0;">
					<h3 style="margin:0 0 6px 0;"><a href="<?php echo esc_url(get_permalink($id)); ?>"><?php echo esc_html(get_the_title($id)); ?></a></h3>
					<?php
						$dayline = '';
						$ts = $sd ? strtotime($sd . ' ' . ($st ? $st : '00:00')) : false;
						if ($ts) {
							$dayline = date_i18n('l', $ts) . ' ' . $sd;
							if ($time_disp) { $dayline .= ' ' . $time_disp; }
						}
					?>
					<?php if ($dayline): ?><div style="margin:0 0 10px 0; opacity:.85;"><?php echo esc_html($dayline); ?></div><?php endif; ?>

					<div>
						<?php if ($city): ?><strong><?php echo esc_html($city); ?></strong><?php endif; ?>
						<?php if ($date_disp): ?> • <span><?php echo esc_html($date_disp); ?></span><?php endif; ?>
						<?php if ($time_disp): ?> • <span><?php echo esc_html($time_disp); ?></span><?php endif; ?>
					</div>
					<?php if ($loc): ?><div style="margin-top:6px;"><?php echo esc_html($loc); ?></div><?php endif; ?>
					<div style="margin-top:10px;"><a class="button" href="<?php echo esc_url($booking); ?>">Boka / Läs mer</a></div>
				</div>
			<?php endwhile; wp_reset_postdata(); ?>
		</div>
		<?php return ob_get_clean();
	}

	// -------------------------------------------------------------------------
	// Cron run: send scheduled mails
	// -----------------------------------------------------------------------------
	public static function cron_run() { /* intentionally left as earlier versions */ }

	// Admin actions used by buttons
	public static function handle_send_test() { /* intentionally left as earlier versions */ }
	public static function handle_resend() { /* intentionally left as earlier versions */ }
	public static function handle_copy_new() { /* intentionally left as earlier versions */ }

	// -------------------------------------------------------------------------
	// Mail builders (used in editor preview)
	// -----------------------------------------------------------------------------
	public static function build_subject($post_id) {
		$opt = self::get_options();

		$subject_tpl = get_post_meta($post_id, self::META_SUBJECT_OVERRIDE, true);
		if ($subject_tpl == '') { $subject_tpl = $opt['default_subject_tpl']; }

		$title = get_the_title($post_id);
		$city  = self::get_city_display($post_id);
		$sd    = get_post_meta($post_id, self::META_START_DATE, true);

		$date_disp = self::format_date_display($sd);

		$subject = str_replace(array('{title}','{city}','{date}'), array($title, $city, $date_disp), $subject_tpl);
		return trim($subject);
	}

	public static function build_mail_preview($post_id, $with_labels = false) {
		$opt = self::get_options();
		$order = $opt['mail_field_order'];

		$title = get_the_title($post_id);
		$content = wp_strip_all_tags(get_post_field('post_content', $post_id));
		$content = trim($content);

		$sd = get_post_meta($post_id, self::META_START_DATE, true);
		$st = get_post_meta($post_id, self::META_START_TIME, true);
		$et = get_post_meta($post_id, self::META_END_TIME, true);

		$loc = self::get_location_display($post_id);

		$cover_id = intval(get_post_meta($post_id, self::META_COVER_IMAGE_ID, true));
		$cover_url = '';
		if ($cover_id) {
			$cover_url = wp_get_attachment_url($cover_id);
		} else {
			$cover_url = get_post_meta($post_id, self::META_COVER_IMAGE_URL, true);
		}

		$date_disp = self::format_date_display($sd);
		$time_disp = self::format_time_display($st, $et);

		$values = array(
			'cover_url' => $cover_url,
			'title'     => $title,
			'content'   => $content,
			'date'      => $date_disp,
			'time'      => $time_disp,
			'location'  => $loc,
		);

		$lines = array();
		foreach ($order as $field) {
			if (!isset($values[$field])) { continue; }
			$val = trim((string)$values[$field]);
			if ($val == '') { continue; }

			if ($with_labels) {
				$label = isset(self::known_mail_fields()[$field]) ? self::known_mail_fields()[$field] : $field;
				$lines[] = $label . ': ' . $val;
			} else {
				$lines[] = $val;
			}
		}
		return implode("\n\n", $lines);
	}

	// -------------------------------------------------------------------------
	// Helpers: date/time formatting
	// -----------------------------------------------------------------------------
	public static function format_date_display($start_date) {
		$opt = self::get_options();
		$mode = $opt['date_format_mode'];

		if ($start_date == '') { return ''; }
		$ts = strtotime($start_date . ' 00:00:00');
		if (!$ts) { return $start_date; }

		switch ($mode) {
			case 'iso': return date_i18n('Y-m-d', $ts);
			case 'slash': return date_i18n('d/m/Y', $ts);
			case 'short_month': return date_i18n('j M Y', $ts);
			case 'custom':
				$fmt = trim($opt['date_format_custom']);
				if ($fmt == '') { $fmt = 'Y-m-d'; }
				return date_i18n($fmt, $ts);
			case 'human_long':
			default:
				return date_i18n('j F Y', $ts);
		}
	}

	public static function format_time_display($start_time, $end_time) {
		$opt = self::get_options();
		$mode = $opt['time_format_mode'];

		$st = trim((string)$start_time);
		$et = trim((string)$end_time);

		if ($st == '' && $et == '') { return ''; }

		if ($mode === 'start_only') {
			return $st != '' ? $st : '';
		}

		if ($mode === 'custom') {
			$tpl = trim((string)$opt['time_format_custom']);
			if ($tpl == '') { $tpl = '{start_time}–{end_time}'; }
			return str_replace(array('{start_time}','{end_time}'), array($st, $et), $tpl);
		}

		if ($st != '' && $et != '') { return $st . '–' . $et; }
		return $st != '' ? $st : $et;
	}

	// -------------------------------------------------------------------------
	// City/Location display helpers
	// -----------------------------------------------------------------------------
	public static function get_city_display($post_id) {
		$opt = self::get_options();
		$city_opt = get_post_meta($post_id, self::META_CITY_OPTION, true);
		$city_other = get_post_meta($post_id, self::META_CITY_OTHER, true);

		if ($city_opt == '') { $city_opt = $opt['default_city_option']; }
		if ($city_other == '') { $city_other = $opt['default_city_other']; }

		if ($city_opt === 'norrkoping') { return 'Norrköping'; }
		if ($city_opt === 'nykoping') { return 'Nyköping'; }
		if ($city_opt === 'other') { return trim((string)$city_other); }
		return '';
	}

	public static function get_location_display($post_id) {
		$opt = self::get_options();
		$loc_opt = get_post_meta($post_id, self::META_LOCATION_OPTION, true);
		$loc_other = get_post_meta($post_id, self::META_LOCATION_OTHER, true);

		if ($loc_opt == '') { $loc_opt = $opt['default_location_option']; }
		if ($loc_other == '') { $loc_other = $opt['default_location_other']; }

		if ($loc_opt === 'borgen') { return 'Borgen'; }
		if ($loc_opt === 'sunlight_hotel') { return 'Sunlight Hotel'; }
		if ($loc_opt === 'sunlight_gymspa') { return 'Sunlight Gym & SPA'; }
		if ($loc_opt === 'other') { return trim((string)$loc_other); }
		return '';
	}

	public static function to_datetime_local($ymdhm) {
		$ymdhm = trim((string)$ymdhm);
		if ($ymdhm == '') { return ''; }
		$ymdhm = str_replace('T', ' ', $ymdhm);
		if (preg_match('/^\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}\\:\\d{2}$/', $ymdhm)) {
			return str_replace(' ', 'T', $ymdhm);
		}
		if (preg_match('/^\\d{4}\\-\\d{2}\\-\\d{2}T\\d{2}\\:\\d{2}$/', $ymdhm)) {
			return $ymdhm;
		}
		return '';
	}

	public static function from_datetime_local($val) {
		$val = trim((string)$val);
		if ($val == '') { return ''; }
		$val = str_replace('T', ' ', $val);
		if (preg_match('/^\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}\\:\\d{2}$/', $val)) {
			return $val;
		}
		return '';
	}

	public static function sanitize_time_hhmm($t) {
		$t = trim((string)$t);
		if ($t == '') { return ''; }
		if (preg_match('/^\\d{2}\\:\\d{2}$/', $t)) { return $t; }
		if (preg_match('/^(\\d{2})\\:(\\d{2})\\:\\d{2}$/', $t, $m)) { return $m[1] . ':' . $m[2]; }
		return '';
	}

	// -------------------------------------------------------------------------
	// Dans.se API helpers
	// -----------------------------------------------------------------------------
	public static function parse_group_ids($csv) {
		$csv = trim((string)$csv);
		if ($csv === '') { return array(); }
		$parts = preg_split('/[\\s,;]+/', $csv);
		$out = array();
		foreach ($parts as $p) {
			$p = trim($p);
			if ($p === '') { continue; }
			if (preg_match('/^\\d+$/', $p)) { $out[] = intval($p); }
		}
		return array_values(array_unique($out));
	}

	public static function dans_get_events_list_cached() {
		$opt = self::get_options();
		$cache_key = 'tnu_fbevent_dans_list_v1';
		$cached = get_transient($cache_key);
		if (is_array($cached)) { return $cached; }

		$url = add_query_arg(array('org' => 'tdans', 'pw' => '', 'regStatus' => $opt['dans_reg_status']), self::DANS_PUBLIC_EVENTS_ENDPOINT);
		$resp = wp_remote_get($url, array('timeout' => 20));
		if (is_wp_error($resp)) { return array(); }
		$code = wp_remote_retrieve_response_code($resp);
		if ($code < 200 || $code >= 300) { return array(); }

		$body = wp_remote_retrieve_body($resp);
		$json = json_decode($body, true);
		$events = array();

		if (is_array($json) && isset($json['events']) && is_array($json['events'])) {
			$events = $json['events'];
		} else if (is_array($json) && isset($json[0]) && is_array($json[0])) {
			$events = $json;
		}

		set_transient($cache_key, $events, 15 * MINUTE_IN_SECONDS);
		return $events;
	}

	public static function dans_get_event_by_id($dans_id) {
		$dans_id = intval($dans_id);
		if ($dans_id <= 0) { return null; }

		$opt = self::get_options();

		$cache_key = 'tnu_fbevent_dans_single_' . $dans_id;
		$cached = get_transient($cache_key);
		if (is_array($cached)) { return $cached; }

		$url = add_query_arg(array('org' => 'tdans', 'pw' => '', 'id' => $dans_id, 'regStatus' => $opt['dans_reg_status']), self::DANS_PUBLIC_EVENTS_ENDPOINT);
		$resp = wp_remote_get($url, array('timeout' => 20));
		if (is_wp_error($resp)) { return null; }
		$code = wp_remote_retrieve_response_code($resp);
		if ($code < 200 || $code >= 300) { return null; }

		$body = wp_remote_retrieve_body($resp);
		$json = json_decode($body, true);
		$event = null;

		if (is_array($json) && isset($json['events'][0])) {
			$event = $json['events'][0];
		} else if (is_array($json) && isset($json[0])) {
			$event = $json[0];
		}

		if (is_array($event)) {
			set_transient($cache_key, $event, 15 * MINUTE_IN_SECONDS);
			return $event;
		}
		return null;
	}

	public static function find_post_id_by_dans_event_id($dans_id) {
		$dans_id = (string)intval($dans_id);
		if ($dans_id === '0') { return 0; }

		$q = new WP_Query(array(
			'post_type'      => self::CPT,
			'post_status'    => array('publish','future','draft','pending','private'),
			'posts_per_page' => 1,
			'meta_query'     => array(
				array('key' => self::META_DANS_EVENT_ID, 'value' => $dans_id)
			),
			'fields' => 'ids',
		));

		if ($q->have_posts()) {
			$ids = $q->posts;
			return intval($ids[0]);
		}
		return 0;
	}

	public static function dans_guess_city_option_from_code($code) {
		$code = strtoupper((string)$code);
		if (strpos($code, '-NOR-') !== false) { return 'norrkoping'; }
		if (strpos($code, '-NYK-') !== false) { return 'nykoping'; }
		return 'other';
	}

	public static function dans_map_location_option($place) {
		$p = strtolower(trim((string)$place));
		if ($p === '') { return array('other',''); }

		if (strpos($p, 'borgen') !== false) { return array('borgen',''); }
		if (strpos($p, 'sunlight') !== false && (strpos($p, 'hotel') !== false)) { return array('sunlight_hotel',''); }
		if (strpos($p, 'sunlight') !== false && (strpos($p, 'gym') !== false || strpos($p, 'spa') !== false)) { return array('sunlight_gymspa',''); }

		return array('other', (string)$place);
	}

	public static function apply_dans_data_to_post($post_id, $event, $update_post_title_and_content = true) {
		$opt = self::get_options();

		$title = isset($event['name']) ? sanitize_text_field($event['name']) : '';

		$sd = isset($event['schedule']['start']['date']) ? sanitize_text_field($event['schedule']['start']['date']) : '';
		$st = isset($event['schedule']['start']['time']) ? sanitize_text_field($event['schedule']['start']['time']) : '';
		$ed = isset($event['schedule']['end']['date']) ? sanitize_text_field($event['schedule']['end']['date']) : '';
		$et = isset($event['schedule']['end']['time']) ? sanitize_text_field($event['schedule']['end']['time']) : '';

		// Meta: Start/Slut (YYYY-MM-DD + 24h)
		update_post_meta($post_id, self::META_START_DATE, $sd);
		update_post_meta($post_id, self::META_START_TIME, self::sanitize_time_hhmm($st));

		// Om sluttid saknas ska vi INTE populera fältet.
		$et_hhmm = self::sanitize_time_hhmm($et);
		if (!empty($ed) || !empty($et_hhmm)) {
			update_post_meta($post_id, self::META_END_DATE, $ed);
		}
		if (!empty($et_hhmm)) {
			update_post_meta($post_id, self::META_END_TIME, $et_hhmm);
		} else {
			delete_post_meta($post_id, self::META_END_TIME);
		}

		// Booking URL
		$reg_url = '';
		if (isset($event['links']['registration'])) {
			$reg_url = esc_url_raw($event['links']['registration']);
		}
		if (empty($reg_url) && !empty($opt['default_booking_url'])) {
			$reg_url = esc_url_raw($opt['default_booking_url']);
		}
		if (!empty($reg_url)) {
			update_post_meta($post_id, self::META_BOOKING_URL, $reg_url);
		}

		// Build content: EVENTDAG EVENTDATUM EVENTSTARTTID + (beskrivning) + EVENTCLOSEREG + BOKNINGSLÄNK
		$desc = '';
		if (isset($event['longdescription']) && !empty($event['longdescription'])) {
			$desc = (string)$event['longdescription'];
		} elseif (isset($event['description']) && !empty($event['description'])) {
			$desc = (string)$event['description'];
		}

		// Ta bort bortkommenterad HTML helt (inkl. innehållet mellan <!-- och -->).
		$desc = self::remove_html_comments($desc);

		// 1) Datumrad överst
		$when_line = '';
		if (!empty($sd) && !empty($st)) {
			$ts = strtotime($sd . ' ' . $st);
			if ($ts) {
				$day = date_i18n('l', $ts);
				$date = date('Y-m-d', $ts);
				$time = date('H:i', $ts);
				$when_line = '<p><strong>' . esc_html($day . ' ' . $date . ' ' . $time) . '</strong></p>' . "\n";
			}
		}

		// 2) Stängningsdatum för anmälan
		$close_line = '';
		if (isset($event['periods']['closeReg']) && !empty($event['periods']['closeReg'])) {
			$cr = sanitize_text_field($event['periods']['closeReg']); // "YYYY-MM-DD HH:MM:SS"
			$cr_ts = strtotime($cr);
			if ($cr_ts) {
				$cr_fmt = date('Y-m-d H:i', $cr_ts);
				$close_line = "\n" . '<p><strong>Anmälan stänger:</strong> ' . esc_html($cr_fmt) . '</p>' . "\n";
			}
		}

		// 3) Bokningslänk
		$booking_line = '';
		if (!empty($reg_url)) {
			$booking_line = "\n" . '<p><strong>Boka här:</strong> ' . esc_html($reg_url) . '</p>' . "\n";
		}

		$desc = $when_line . $desc . $close_line . $booking_line;

		if ($update_post_title_and_content) {
			$upd = array('ID' => $post_id);
			if (!empty($title)) {
				$upd['post_title'] = $title;
			}
			if (!empty($desc)) {
				$upd['post_content'] = $desc;
			}
			wp_update_post($upd);
		}

		// Featured image: 1) profileImageUrl, annars 2) första bild i text, annars behåll (eller fallback via settings om sådan finns).
		$profile_url = '';
		if (isset($event['profileImageUrl']) && !empty($event['profileImageUrl'])) {
			$profile_url = esc_url_raw($event['profileImageUrl']);
		}

		$did_set_thumb = false;

		if (!empty($profile_url)) {
			$att_id = self::import_image_to_media($profile_url, $post_id);
			if ($att_id) {
				set_post_thumbnail($post_id, $att_id);
				$did_set_thumb = true;
			}
		}

		if (!$did_set_thumb && !has_post_thumbnail($post_id) && !empty($desc)) {
			// Försök använda första <img src="..."> i brödtexten som featured.
			if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $desc, $mm) && !empty($mm[1])) {
				$first_img_url = esc_url_raw($mm[1]);
				$att_id2 = self::import_image_to_media($first_img_url, $post_id);
				if ($att_id2) {
					set_post_thumbnail($post_id, $att_id2);
					$did_set_thumb = true;
				}
			}
		}

		// Ort/Plats (valfritt)
		$city = '';
		if (isset($event['location']['city'])) {
			$city = sanitize_text_field($event['location']['city']);
		}
		if (!empty($city)) {
			update_post_meta($post_id, self::META_CITY, $city);
		}

		$place = '';
		if (isset($event['location']['name'])) {
			$place = sanitize_text_field($event['location']['name']);
		}
		if (!empty($place)) {
			update_post_meta($post_id, self::META_PLACE, $place);
		}

		// Spara Dans.se event-id
		if (isset($event['id'])) {
			update_post_meta($post_id, self::META_DANS_EVENT_ID, intval($event['id']));
		}
	}

	public static function import_image_to_media($image_url, $post_id, $title_for_filename='') {
		$image_url = esc_url_raw($image_url);
		if ($image_url === '') { return 0; }

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = download_url($image_url, 20);
		if (is_wp_error($tmp)) { return 0; }

		$filename = basename(parse_url($image_url, PHP_URL_PATH));
		if (!$filename) { $filename = 'cover.jpg'; }

		$file_array = array(
			'name'     => sanitize_file_name($filename),
			'tmp_name' => $tmp,
		);

		$attach_id = media_handle_sideload($file_array, $post_id, $title_for_filename ? $title_for_filename : 'Cover');

		if (is_wp_error($attach_id)) {
			@unlink($tmp);
			return 0;
		}

		return intval($attach_id);
	}

	public static function ajax_fetch_dans_single() {
		if (!current_user_can('edit_posts')) { wp_send_json_error(array('message' => 'No access'), 403); }
		check_ajax_referer('tnu_fbevent_nonce', 'nonce');

		$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
		$dans_id = isset($_POST['dans_id']) ? intval($_POST['dans_id']) : 0;

		if ($post_id <= 0 || $dans_id <= 0) { wp_send_json_error(array('message' => 'Bad input')); }

		$post = get_post($post_id);
		if (!$post || $post->post_type !== self::CPT) { wp_send_json_error(array('message' => 'Not an event')); }

		$data = self::dans_get_event_by_id($dans_id);
		if (!$data) { wp_send_json_error(array('message' => 'No data returned from Dans.se')); }

		self::apply_dans_data_to_post($post_id, $data, true);

		wp_send_json_success(array('message' => 'Import klar: fält uppdaterade (inkl. cover om bild fanns).'));
	}

	// Minimal: next event helper
	public static function get_next_event() {
		$today = date('Y-m-d', current_time('timestamp'));
		$q = new WP_Query(array(
			'post_type'      => self::CPT,
			'post_status'    => array('publish','future'),
			'posts_per_page' => 1,
			'meta_key'       => self::META_START_DATE,
			'orderby'        => 'meta_value',
			'order'          => 'ASC',
			'meta_query'     => array(
				array('key'=>self::META_START_DATE,'value'=>$today,'compare'=>'>=','type'=>'DATE'),
			),
		));
		if ($q->have_posts()) { $q->the_post(); $p = get_post(get_the_ID()); wp_reset_postdata(); return $p; }
		return null;
	}
	public static function filter_single_event_content($content) {
		if (!is_singular(self::CPT) || !in_the_loop() || !is_main_query()) { return $content; }
		$id = get_the_ID();
		$sd = get_post_meta($id, self::META_START_DATE, true);
		$st = get_post_meta($id, self::META_START_TIME, true);
		$et = get_post_meta($id, self::META_END_TIME, true);

		$sd = preg_replace('/[^0-9\-]/', '', (string)$sd);
		$st = preg_replace('/[^0-9:]/', '', (string)$st);
		$et = preg_replace('/[^0-9:]/', '', (string)$et);

		if (!empty($sd) && !empty($st)) {
			$ts = strtotime($sd . ' ' . $st);
			$day = date_i18n('l', $ts);
			$nice = esc_html($day . ' ' . $sd . ' kl ' . substr($st, 0, 5));
			if (!empty($et)) {
				$nice .= '–' . esc_html(substr($et, 0, 5));
			}
			$content = '<p class="tnu-event-when"><strong>' . $nice . '</strong></p>' . $content;
		}

		// Gör allt på single-event klickbart till bokningslänk.
		$opt = self::get_options();
		$booking = get_post_meta($id, self::META_BOOKING_URL, true);
		$booking = is_string($booking) ? trim($booking) : '';
		if (empty($booking) && !empty($opt['default_booking_url'])) {
			$booking = trim((string)$opt['default_booking_url']);
		}
		if (!empty($booking)) {
			$content = '<a class="tnu-event-booking-link" href="' . esc_url($booking) . '">' . $content . '</a>';
		}

		return $content;
	}


	// -----------------------------
	// FRONTEND CSS: dölj temats featured-bild och visa vår egen (skalad)
	public static function enqueue_event_image_css() {

		if (is_admin()) { return; }

		// Gäller: event-archive (/events) + single event
		if (!is_singular(self::CPT) && !is_post_type_archive(self::CPT)) { return; }

		$css = '
/* TNU Event: tvinga skalning och ta över bildvisning */
.post-type-archive-tnu_event img.tnu-event-img,
.single-tnu_event img.tnu-event-img{
	max-width:290px !important;
	max-height:290px !important;
	width:auto !important;
	height:auto !important;
	display:block !important;
}
.post-type-archive-tnu_event .tnu-event-img-wrap,
.single-tnu_event .tnu-event-img-wrap{
	margin: 10px 0 14px 0 !important;
}
/* Klickbarhet: hela excerptet på arkiv, och hela innehållet på single */
.post-type-archive-tnu_event a.tnu-event-archive-link{
	display:block;
	color:inherit;
	text-decoration:none;
	cursor:pointer;
}
.post-type-archive-tnu_event a.tnu-event-archive-link:hover{
	text-decoration:none;
}
.single-tnu_event a.tnu-event-booking-link{
	display:block;
	color:inherit;
	text-decoration:none;
	cursor:pointer;
}
.single-tnu_event a.tnu-event-booking-link:hover{
	text-decoration:none;
}
/* Om temat använder cover/background kan vi inte fånga det med img-filter,
   därför döljer vi vanliga wrappers och visar vår egen i content/excerpt. */
.post-type-archive-tnu_event .post-thumbnail,
.post-type-archive-tnu_event .featured-image,
.post-type-archive-tnu_event .entry-media,
.post-type-archive-tnu_event .entry-thumbnail,
.single-tnu_event .post-thumbnail,
.single-tnu_event .featured-image,
.single-tnu_event .entry-media,
.single-tnu_event .entry-thumbnail{
	display:none !important;
}
';
		// Lägg som inline på frontend
		wp_register_style('tnu-fbevent-inline', false);
		wp_enqueue_style('tnu-fbevent-inline');
		wp_add_inline_style('tnu-fbevent-inline', $css);
	}

	// Lägg klass + inline-style på WP:s featured image HTML när den används
	public static function filter_post_thumbnail_html($html, $post_id, $post_thumbnail_id, $size, $attr) {

		if (!is_singular(self::CPT) && !is_post_type_archive(self::CPT)) { return $html; }

		$post = get_post($post_id);
		if (!$post || $post->post_type !== self::CPT) { return $html; }

		if (!$html) { return $html; }

		// injicera class + style på <img>
		$html = preg_replace('/<img\s+/i', '<img class="tnu-event-img" style="max-width:290px !important; max-height:290px !important; width:auto !important; height:auto !important; display:block !important;" ', $html, 1);

		return $html;
	}

	// Single – visa featured image (full) ovanför texten + skala alla content-bilder
	public static function filter_event_content_images($content) {

		if (!is_singular(self::CPT)) { return $content; }
		if (!in_the_loop() || !is_main_query()) { return $content; }

		$post_id = get_the_ID();

		// Skala alla img i content
		$content = preg_replace('/<img([^>]+)>/i', '<img$1 class="tnu-event-img" style="max-width:290px !important; max-height:290px !important; width:auto !important; height:auto !important; display:block !important;">', $content);

		// Lägg egen featured image-wrap först (så vi inte är beroende av temat)
		if (has_post_thumbnail($post_id)) {
			$img = get_the_post_thumbnail($post_id, 'full', array(
				'class' => 'tnu-event-img',
				'style' => 'max-width:290px !important; max-height:290px !important; width:auto !important; height:auto !important; display:block !important;',
			));
			if ($img) {
				$wrap = '<div class="tnu-event-img-wrap">'.$img.'</div>';
				$content = $wrap . $content;
			}
		}

		return $content;
	}

	// Archive/list – visa featured image (full) i excerpt + skala eventuella excerpt-bilder
	public static function filter_event_excerpt_images($excerpt) {

		if (!is_post_type_archive(self::CPT)) { return $excerpt; }
		if (!in_the_loop() || !is_main_query()) { return $excerpt; }

		$post_id = get_the_ID();
		$permalink = get_permalink($post_id);

		$excerpt = preg_replace('/<img([^>]+)>/i', '<img$1 class="tnu-event-img" style="max-width:290px !important; max-height:290px !important; width:auto !important; height:auto !important; display:block !important;">', $excerpt);

		if (has_post_thumbnail($post_id)) {
			$img = get_the_post_thumbnail($post_id, 'sosimple-featured', array(
				'class' => 'tnu-event-img',
				'style' => 'max-width:290px !important; max-height:290px !important; width:auto !important; height:auto !important; display:block !important;',
			));
			if (!empty($img)) {
				$excerpt = '<a class="tnu-event-archive-link" href="' . esc_url($permalink) . '">' .
					'<div class="tnu-event-img-wrap">' . $img . '</div>' .
					$excerpt .
				'</a>';
			}
		} else {
			// Ingen featured: gör ändå texten klickbar in till eventet.
			$excerpt = '<a class="tnu-event-archive-link" href="' . esc_url($permalink) . '">' . $excerpt . '</a>';
		}

		return $excerpt;
	}

}

TNU_FB_Event_Plan::init();
