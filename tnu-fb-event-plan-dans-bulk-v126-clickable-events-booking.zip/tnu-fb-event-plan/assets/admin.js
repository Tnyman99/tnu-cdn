jQuery(function($){
	var $sortable = $('#tnu-mail-field-sortable');
	if ($sortable.length) {
		$sortable.sortable({
			placeholder: 'tnu-sortable-placeholder',
			update: function(){
				var order = [];
				$sortable.find('.tnu-sortable-item').each(function(){
					order.push($(this).data('field'));
				});
				$('#mail_field_order_json').val(JSON.stringify(order));
			}
		});
	}

	$('#tnu_fetch_check_all').on('change', function(){
		$('.tnu_fetch_chk').prop('checked', $(this).is(':checked'));
	});

	$('#tnu_dans_fetch_btn').on('click', function(e){
		e.preventDefault();

		var postId = $(this).data('postid');
		var dansId = parseInt($('#tnu_dans_event_id').val(), 10);

		if (!postId || !dansId) {
			$('#tnu_dans_fetch_status').html('<div class="notice notice-error"><p>Fyll i Dans.se Event ID.</p></div>');
			return;
		}

		$('#tnu_dans_fetch_status').html('<div class="notice notice-info"><p>Hämtar från Dans.se...</p></div>');

		$.post(TNU_FBEVENT.ajaxUrl, {
			action: 'tnu_fbevent_fetch_dans_single',
			nonce: TNU_FBEVENT.nonce,
			post_id: postId,
			dans_id: dansId
		})
		.done(function(resp){
			if (resp && resp.success) {
				$('#tnu_dans_fetch_status').html('<div class="notice notice-success"><p>'+ (resp.data && resp.data.message ? resp.data.message : 'OK') +'</p></div>');
			} else {
				$('#tnu_dans_fetch_status').html('<div class="notice notice-error"><p>'+ (resp.data && resp.data.message ? resp.data.message : 'Fel') +'</p></div>');
			}
		})
		.fail(function(xhr){
			var msg = 'Fel vid anrop.';
			if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
				msg = xhr.responseJSON.data.message;
			}
			$('#tnu_dans_fetch_status').html('<div class="notice notice-error"><p>'+ msg +'</p></div>');
		});
	});
});
